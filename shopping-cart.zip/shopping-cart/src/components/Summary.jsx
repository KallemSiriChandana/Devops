function Summary({ totalItems, subtotal, discount, total }) {
  const delivery = subtotal > 2000 ? 0 : 99;

  return (
    <aside className="summary">
      <div className="summary-title">
        <h2>Order Summary</h2>
        <span>{totalItems} item{totalItems !== 1 ? "s" : ""}</span>
      </div>

      <div className="summary-row">
        <span>Subtotal</span>
        <strong>₹{subtotal.toLocaleString("en-IN")}</strong>
      </div>

      <div className="summary-row">
        <span>Discount</span>
        <strong className={discount > 0 ? "discount" : ""}>
          {discount > 0 ? `− ₹${discount.toLocaleString("en-IN")}` : "₹0"}
        </strong>
      </div>

      <div className="summary-row">
        <span>Delivery</span>
        <strong>{delivery === 0 ? <span className="free">FREE</span> : `₹${delivery}`}</strong>
      </div>

      {subtotal > 2000 && (
        <div className="delivery-note">✓ Free Delivery unlocked!</div>
      )}

      {subtotal > 5000 && (
        <div className="discount-note">🎉 10% discount applied on orders above ₹5,000.</div>
      )}

      <div className="summary-total">
        <span>Total</span>
        <strong>₹{(total + delivery).toLocaleString("en-IN")}</strong>
      </div>

      <button className="checkout-btn" disabled={totalItems === 0}>
        Proceed to Checkout →
      </button>
    </aside>
  );
}

export default Summary;