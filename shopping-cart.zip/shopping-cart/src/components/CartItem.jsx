function CartItem({ item, onIncrease, onDecrease, onRemove }) {
  return (
    <div className="cart-item">
      <img src={item.image} alt={item.name} className="cart-item-image" />
      <div className="cart-item-info">
        <div>
          <h4>{item.name}</h4>
          <p>{item.category} · {item.id}</p>
        </div>
        <strong>₹{(item.price * item.quantity).toLocaleString("en-IN")}</strong>
        <div className="quantity-row">
          <div className="quantity-control">
            <button onClick={() => onDecrease(item.id)} aria-label={`Decrease ${item.name}`}>−</button>
            <span>{item.quantity}</span>
            <button onClick={() => onIncrease(item.id)} aria-label={`Increase ${item.name}`}>+</button>
          </div>
          <button className="remove-btn" onClick={() => onRemove(item.id)}>Remove</button>
        </div>
      </div>
    </div>
  );
}

export default CartItem;