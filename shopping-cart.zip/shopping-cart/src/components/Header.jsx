function Header({ cartCount }) {
  return (
    <header className="header">
      <div className="header-inner">
        <div className="brand">
          <div className="brand-icon">🛒</div>
          <div>
            <h1>Online Shopping Cart</h1>
            <p>React Props &amp; State Management</p>
          </div>
        </div>
        <div className="cart-badge">
          <span>Cart</span>
          <strong>{cartCount}</strong>
        </div>
      </div>
    </header>
  );
}

export default Header;