function SearchBar({ search, setSearch, category, setCategory }) {
  return (
    <div className="filters">
      <div className="search-box">
        <span>⌕</span>
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search products..."
        />
        {search && (
          <button className="input-clear" onClick={() => setSearch("")}>×</button>
        )}
      </div>

      <select value={category} onChange={(e) => setCategory(e.target.value)}>
        <option value="All">All Categories</option>
        <option value="Electronics">Electronics</option>
        <option value="Accessories">Accessories</option>
        <option value="Fashion">Fashion</option>
      </select>
    </div>
  );
}

export default SearchBar;