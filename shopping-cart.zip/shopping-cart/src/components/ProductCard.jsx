function ProductCard({ name, price, category, id, image, onAdd }) {
  return (
    <article className="product-card">
      <div className="product-image-wrap">
        <img src={image} alt={name} className="product-image" />
        <span className="category-pill">{category}</span>
      </div>
      <div className="product-content">
        <div className="product-top">
          <span className="product-id">{id}</span>
          <h3>{name}</h3>
        </div>
        <div className="product-bottom">
          <strong>₹{price.toLocaleString("en-IN")}</strong>
          <button className="primary-btn" onClick={() => onAdd({ id, name, category, price, image })}>
            + Add to Cart
          </button>
        </div>
      </div>
    </article>
  );
}

export default ProductCard;