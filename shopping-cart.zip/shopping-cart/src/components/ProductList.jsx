import ProductCard from "./ProductCard";

function ProductList({ products, onAdd }) {
  return (
    <section className="products-section">
      <div className="section-heading">
        <div>
          <p className="eyebrow">PRODUCTS</p>
          <h2>Available Products</h2>
        </div>
        <span className="result-count">{products.length} items</span>
      </div>

      {products.length === 0 ? (
        <div className="empty-products">
          <div>🔎</div>
          <h3>No products found</h3>
          <p>Try a different search term or category.</p>
        </div>
      ) : (
        <div className="product-grid">
          {products.map((product) => (
            <ProductCard
              key={product.id}
              name={product.name}
              price={product.price}
              category={product.category}
              id={product.id}
              image={product.image}
              onAdd={onAdd}
            />
          ))}
        </div>
      )}
    </section>
  );
}

export default ProductList;