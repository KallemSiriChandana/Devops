import CartItem from "./CartItem";

function Cart({ cart, onIncrease, onDecrease, onRemove, onClear }) {
  return (
    <section className="cart-section">
      <div className="section-heading">
        <div>
          <p className="eyebrow">YOUR CART</p>
          <h2>Shopping Cart</h2>
        </div>
        {cart.length > 0 && (
          <button className="clear-btn" onClick={onClear}>Clear Cart</button>
        )}
      </div>

      {cart.length === 0 ? (
        <div className="empty-cart">
          <div className="empty-cart-icon">🛍️</div>
          <h3>Your cart is empty</h3>
          <p>Add a product to start shopping.</p>
        </div>
      ) : (
        <div className="cart-list">
          {cart.map((item) => (
            <CartItem
              key={item.id}
              item={item}
              onIncrease={onIncrease}
              onDecrease={onDecrease}
              onRemove={onRemove}
            />
          ))}
        </div>
      )}
    </section>
  );
}

export default Cart;