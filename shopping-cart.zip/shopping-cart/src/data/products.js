export const products = [
  {
    id: "P101",
    name: "Laptop",
    category: "Electronics",
    price: 60000,
    quantity: 1,
    image: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=800&q=80"
  },
  {
    id: "P102",
    name: "Headphones",
    category: "Electronics",
    price: 2000,
    quantity: 1,
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=800&q=80"
  },
  {
    id: "P103",
    name: "Backpack",
    category: "Accessories",
    price: 1500,
    quantity: 1,
    image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=800&q=80"
  },
  {
    id: "P104",
    name: "Smart Watch",
    category: "Electronics",
    price: 4500,
    quantity: 1,
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=800&q=80"
  },
  {
    id: "P105",
    name: "Running Shoes",
    category: "Fashion",
    price: 3200,
    quantity: 1,
    image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=800&q=80"
  },
  {
    id: "P106",
    name: "Sunglasses",
    category: "Fashion",
    price: 1800,
    quantity: 1,
    image: "https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=800&q=80"
  }
];