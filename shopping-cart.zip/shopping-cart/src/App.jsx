import { useMemo, useState } from "react";
import Header from "./components/Header";
import ProductList from "./components/ProductList";
import Cart from "./components/Cart";
import Summary from "./components/Summary";
import SearchBar from "./components/SearchBar";
import { products } from "./data/products";

function App() {
  const [cart, setCart] = useState([]);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");

  const filteredProducts = useMemo(() => {
    return products.filter((product) => {
      const matchesSearch =
        product.name.toLowerCase().includes(search.toLowerCase()) ||
        product.id.toLowerCase().includes(search.toLowerCase());

      const matchesCategory =
        category === "All" || product.category === category;

      return matchesSearch && matchesCategory;
    });
  }, [search, category]);

  const handleAddToCart = (product) => {
    setCart((currentCart) => {
      const existing = currentCart.find((item) => item.id === product.id);

      if (existing) {
        return currentCart.map((item) =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }

      return [...currentCart, { ...product, quantity: 1 }];
    });
  };

  const handleIncrease = (id) => {
    setCart((currentCart) =>
      currentCart.map((item) =>
        item.id === id ? { ...item, quantity: item.quantity + 1 } : item
      )
    );
  };

  const handleDecrease = (id) => {
    setCart((currentCart) =>
      currentCart
        .map((item) =>
          item.id === id ? { ...item, quantity: item.quantity - 1 } : item
        )
        .filter((item) => item.quantity > 0)
    );
  };

  const handleRemove = (id) => {
    setCart((currentCart) => currentCart.filter((item) => item.id !== id));
  };

  const handleClear = () => setCart([]);

  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = cart.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  const discount = subtotal > 5000 ? Math.round(subtotal * 0.1) : 0;
  const total = subtotal - discount;

  return (
    <div className="app">
      <Header cartCount={totalItems} />

      <main className="container">
        <section className="hero">
          <div>
            <p className="eyebrow">SHOP SMART</p>
            <h2>Everything you need,<br /><span>in one cart.</span></h2>
            <p className="hero-text">
              Browse products, manage quantities, and see your bill update instantly.
            </p>
          </div>
          <div className="hero-card">
            <div className="hero-card-icon">⚡</div>
            <div>
              <strong>React State Demo</strong>
              <p>Props + useState()</p>
            </div>
          </div>
        </section>

        <SearchBar
          search={search}
          setSearch={setSearch}
          category={category}
          setCategory={setCategory}
        />

        <div className="main-grid">
          <div>
            <ProductList products={filteredProducts} onAdd={handleAddToCart} />
            <Cart
              cart={cart}
              onIncrease={handleIncrease}
              onDecrease={handleDecrease}
              onRemove={handleRemove}
              onClear={handleClear}
            />
          </div>

          <div className="summary-column">
            <Summary
              totalItems={totalItems}
              subtotal={subtotal}
              discount={discount}
              total={total}
            />
          </div>
        </div>
      </main>

      <footer>
        <p>Online Shopping Cart · React Props &amp; useState() Assignment</p>
      </footer>
    </div>
  );
}

export default App;