# Online Shopping Cart

A complete React assignment project demonstrating **Props** and **State Management with `useState()`**.

## Features

- Product listing with reusable `ProductCard`
- Props passed from `ProductList` to `ProductCard`
- Add products to cart
- Remove products
- Increase/decrease quantity
- Dynamic total item count
- Dynamic bill calculation
- Conditional empty-cart rendering
- Search products
- Category filtering
- Clear cart
- 10% discount when subtotal exceeds ₹5,000
- Free delivery when subtotal exceeds ₹2,000
- Responsive design
- Reusable Header, ProductList, ProductCard, Cart, CartItem, Summary, and SearchBar components

## Project Structure

```text
shopping-cart/
├── public/
├── src/
│   ├── components/
│   │   ├── Header.jsx
│   │   ├── ProductList.jsx
│   │   ├── ProductCard.jsx
│   │   ├── Cart.jsx
│   │   ├── CartItem.jsx
│   │   ├── Summary.jsx
│   │   └── SearchBar.jsx
│   ├── data/
│   │   └── products.js
│   ├── App.jsx
│   ├── main.jsx
│   └── styles.css
├── index.html
├── package.json
└── README.md
```

## How to Run in VS Code

### 1. Install Node.js

Install the current LTS version of Node.js from:

https://nodejs.org/

Check installation:

```bash
node -v
npm -v
```

### 2. Open the project

Extract the ZIP and open the `shopping-cart` folder in VS Code.

### 3. Install dependencies

Open the VS Code terminal:

```bash
npm install
```

### 4. Start the development server

```bash
npm run dev
```

Vite will show a local URL similar to:

```text
http://localhost:5173/
```

Open it in your browser.

### 5. Create a production build

```bash
npm run build
```

## Main React Concepts Demonstrated

### Props

`ProductList` sends product information to `ProductCard`:

```jsx
<ProductCard
  name={product.name}
  price={product.price}
  category={product.category}
  onAdd={onAdd}
/>
```

### State

The parent `App` component manages the shopping cart:

```jsx
const [cart, setCart] = useState([]);
```

### Add to Cart

```jsx
const handleAddToCart = (product) => {
  setCart((currentCart) => {
    const existing = currentCart.find((item) => item.id === product.id);

    if (existing) {
      return currentCart.map((item) =>
        item.id === product.id
          ? { ...item, quantity: item.quantity + 1 }
          : item
      );
    }

    return [...currentCart, { ...product, quantity: 1 }];
  });
};
```

### Dynamic Calculation

```jsx
const totalItems = cart.reduce(
  (sum, item) => sum + item.quantity,
  0
);

const subtotal = cart.reduce(
  (sum, item) => sum + item.price * item.quantity,
  0
);
```

## Assignment Mapping

| Requirement | Implementation |
|---|---|
| Header | `Header.jsx` |
| ProductList | `ProductList.jsx` |
| ProductCard | `ProductCard.jsx` |
| Cart | `Cart.jsx` |
| CartItem | `CartItem.jsx` |
| Summary | `Summary.jsx` |
| Props | Product and event data passed between components |
| State | `useState()` in `App.jsx` |
| Search | `SearchBar.jsx` |
| Category filter | `SearchBar.jsx` |
| Clear cart | `Cart.jsx` |
| Discount | `Summary.jsx` |
| Free delivery | `Summary.jsx` |
| Dynamic bill | `App.jsx` + `Summary.jsx` |

## Important

The product images use remote Unsplash URLs, so an internet connection is recommended while running the app.